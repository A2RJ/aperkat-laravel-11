<?php $__env->startSection('title', 'Preview PPUF | APERKAT'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card shadow">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Preview PPUF</h6>
            </div>

            <div class="card-body p-4">
                <div class="table-responsive ">
                    <table class="table table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Unit Kerja</th>
                                <th scope="col">Unit Pengaju</th>
                                <th scope="col">Nomor PPUF</th>
                                <th scope="col">Jenis Program</th>
                                <th scope="col">Nama Program</th>
                                <th scope="col">Tempat & Waktu</th>
                                <th scope="col">RAB</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ppufs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ppuf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($ppuf['role']); ?></td>
                                <td><?php echo e($ppuf['parent']); ?></td>
                                <td><?php echo e($ppuf['ppuf_number']); ?></td>
                                <td><?php echo e(ucfirst($ppuf['activity_type'])); ?></td>
                                <td><?php echo e($ppuf['program_name']); ?></td>
                                <td><?php echo e($ppuf['place']); ?>, <?php echo e($ppuf['date']); ?></td>
                                <td><?php echo e(money($ppuf['budget'], 'IDR', true)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="mb-4 d-flex justify-content-between ">
                    <a href="<?php echo e(route('ppuf.import')); ?>" class="btn btn-dark ">Cancel</a>
                    <form action="<?php echo e(route('ppuf.import')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="token" value="<?php echo e($token); ?>">
                        <button class="btn bg-primary btn-primary" type="submit">Save PPUF</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aperkat-laravel-11\resources\views/ppuf/preview.blade.php ENDPATH**/ ?>