 <div class="sidebar-heading">
     User
 </div>
 <li class="nav-item">
     <a class="nav-link" href="<?php echo e(route('ppuf.index')); ?>">
         <i class="fas fa-fw fa-table"></i>
         <span>PPUF</span>
     </a>
 </li>

 <li class="nav-item">
     <a class="nav-link" href="<?php echo e(route('submission.index')); ?>">
         <i class="fas fa-fw fa-table"></i>
         <span>Pengajuan</span>
     </a>
 </li>

 <?php if(auth()->user()->hasSubDivision()->pluck('id')->toArray()): ?>
 <li class="nav-item">
     <a class="nav-link" href="<?php echo e(route('submission.sub-division')); ?>">
         <i class="fas fa-fw fa-folder"></i>
         <span>Pengajuan Sub Divisi</span>
     </a>
 </li>
 <?php endif; ?><?php /**PATH D:\aperkat-laravel-11\resources\views/layout/user.blade.php ENDPATH**/ ?>