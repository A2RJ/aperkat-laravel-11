 <div class="sidebar-heading">
     Warek II
 </div>
 <li class="nav-item">
     <a class="nav-link" href="<?php echo e(route('ppuf.index')); ?>">
         <i class="fas fa-fw fa-table"></i>
         <span>PPUF</span>
     </a>
 </li>

 <li class="nav-item">
     <a class="nav-link" href="<?php echo e(route('submission.index')); ?>">
         <i class="fas fa-fw fa-table"></i>
         <span>Pengajuan</span>
     </a>
 </li>

 <li class="nav-item">
     <a class="nav-link" href="<?php echo e(route('submission.wr2')); ?>">
         <i class="fas fa-fw fa-folder"></i>
         <span>Pengajuan Sub Divisi</span>
     </a>
 </li>
<?php /**PATH D:\aperkat-laravel-11\resources\views/layout/wr2.blade.php ENDPATH**/ ?>