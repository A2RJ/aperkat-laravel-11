<?php $__env->startSection('title', 'Daftar Pengajuan PPUF | APERKAT'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card shadow">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Daftar Pengajuan Sub Divisi</h6>
            </div>

            <div class="card-body p-4">
                <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>.
                </div>
                <?php endif; ?>

                <div id="successMessage" class="alert alert-success" style="display: none;">
                    Pengajuan pada periode terpilih berhasil diterima. Halaman akan dimuat ulang dalam <span id="countdown"></span>.
                </div>

                <?php if(session()->has('failed')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('failed')); ?>.
                </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <div class="mb-4">
                    <form action="<?php echo e(url()->current()); ?>" method="get">
                        <div class="row">
                            <div class="col-sm">
                                <select id="status" class="form-control" name="status">
                                    <option value="">Pilih Status</option>
                                    <option value="need approve" <?php echo e(request('status', false) == 'need approve' ? 'selected' : ''); ?>>
                                        Menunggu Persetujuan
                                    </option>
                                    <option value="progress" <?php echo e(request('status', false) == 'progress' ? 'selected' : ''); ?>>
                                        Sedang Diproses</option>
                                    <option value="done" <?php echo e(request('status', false) == 'done' ? 'selected' : ''); ?>>
                                        Selesai
                                    </option>
                                </select>
                            </div>
                            <div class="col-sm ">
                                <input class="form-control " type="date" id="start" name="start" value="<?php echo e(request('start')); ?>" />
                            </div>
                            <div class="col-sm ">
                                <input class="form-control " type="date" id="end" name="end" value="<?php echo e(request('end')); ?>" />
                            </div>
                            <div class="col-sm ">
                                <input class="form-control " type="text" id="keyword" name="keyword" value="<?php echo e(request('keyword')); ?>" placeholder="Keyword">
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-sm">
                                <select class="w-100 border rounded selectpicker" id="period" name="period" data-live-search="true">
                                    <option value="">Pilih Periode</option>
                                    <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($period->id); ?>" <?php echo e(request('period') == $period->id ? 'selected' : ''); ?>><?php echo e($period->period); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php if(request('period') && request('status') == 'need approve'): ?>
                            <div class="col-sm">
                                <button id="approveSubmission" class="btn bg-success btn-success">Terima pengajuan</button>
                            </div>
                            <?php endif; ?>
                            <div class="col-sm">
                                <button class="btn bg-primary btn-primary " type="submit">Filter</button>
                                <a href="<?php echo e(url()->current()); ?>"><button class="btn bg-warning btn-warning" type="button">Clear</button></a>
                            </div>
                            <div class="col-sm">
                            </div>
                        </div>
                    </form>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Unit Pengaju</th>
                                <th scope="col">Status Pengajuan</th>
                                <th scope="col">Nomor PPUF</th>
                                <th scope="col">Nama Kegiatan</th>
                                <th scope="col">Latar Belakang</th>
                                <th scope="col">Tempat dan Waktu</th>
                                <th scope="col">RAB diajukan</th>
                                <th scope="col">RAB disetujui</th>
                                <th scope="col">Periode</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration + $submissions->firstItem() - 1); ?></th>
                                <td><?php echo e($submission->ppuf->author->role); ?></td>
                                <td class="<?php echo e($submission->status->last()->status ? 'text-success ': 'text-warning '); ?>">
                                    <?php if($submission->status->last()->message == 'LPJ telah disetujui'): ?>
                                    Selesai
                                    <?php else: ?>
                                    <?php echo e($submission->status->last()->role->role); ?>: <?php echo e(substr($submission->status->last()->message, 0, 10)); ?>...
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($submission->ppuf->ppuf_number); ?></td>
                                <td><?php echo e($submission->ppuf->program_name); ?></td>
                                <td><?php echo e($submission->background); ?></td>
                                <td><?php echo e($submission->place); ?>, <?php echo e($submission->date); ?></td>
                                <td><?php echo e($submission->budget); ?></td>
                                <td><?php echo e($submission->approved_budget); ?></td>
                                <td><?php echo e($submission->period?->period); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <a class="btn btn-sm btn-success mr-1 mb-1" href="<?php echo e(route('submission.show', $submission->id)); ?>" target="_blank">
                                            <i class="fas fa-fw fa-info"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="float-right ">
                        <?php echo e($submissions->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptjs'); ?>
<script src="/sb-admin-2/vendor/bootstrap-select/bootstrap-select.min.js"></script>
<script type="text/javascript" charset="utf-8">
    $(function() {
        $('.selectpicker').selectpicker()

        $('#approveSubmission').click(function(e) {
            e.preventDefault();
            var period = "<?php echo e(request('period')); ?>";

            if (!period) {
                return;
            }

            $.ajax({
                url: "<?php echo e(route('submission.wr2.approve', ['period' => ':period'])); ?>".replace(':period', period),
                type: "POST",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    $('#successMessage').show();

                    var secondsLeft = 5; // Set countdown awal 5 detik
                    updateCountdown(secondsLeft); // Tampilkan countdown awal

                    // Jalankan countdown
                    var countdownInterval = setInterval(function() {
                        secondsLeft--; // Kurangi detik yang tersisa
                        updateCountdown(secondsLeft); // Tampilkan countdown yang diperbarui

                        // Jika waktu countdown habis, reload halaman
                        if (secondsLeft <= 0) {
                            clearInterval(countdownInterval); // Hentikan countdown
                            location.reload(); // Reload halaman
                        }
                    }, 1000);
                },
                error: (xhr, status, error) => console.error(error)
            });
        });

        function updateCountdown(seconds) {
            // Tampilkan countdown di elemen dengan id "countdown"
            document.getElementById("countdown").innerHTML = seconds + " detik";
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aperkat-laravel-11\resources\views/submission/wr2/index.blade.php ENDPATH**/ ?>