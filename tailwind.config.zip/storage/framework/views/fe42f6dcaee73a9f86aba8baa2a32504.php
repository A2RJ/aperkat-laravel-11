 <div class="sidebar-heading">
     Warek II
 </div>
 <li class="nav-item">
     <a class="nav-link" href="<?php echo e(route('ppuf.index')); ?>">
         <i class="fas fa-fw fa-table"></i>
         <span>PPUF</span>
     </a>
 </li>

 <li class="nav-item">
     <a class="nav-link" href="<?php echo e(route('submission.index')); ?>">
         <i class="fas fa-fw fa-table"></i>
         <span>Pengajuan</span>
     </a>
 </li>

 <li class="nav-item">
     <a class="nav-link" href="<?php echo e(route('submission.sub-division')); ?>">
         <i class="fas fa-fw fa-folder"></i>
         <span>Pengajuan Sub Divisi</span>
     </a>
 </li>

 <!-- Divider -->
 <hr class="sidebar-divider">

 <!-- Heading -->
 <div class="sidebar-heading">
     Super Admin
 </div>
 <li class="nav-item">
     <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
         <i class="fas fa-fw fa-users"></i>
         <span>Pengguna</span>
     </a>
 </li>
 <li class="nav-item">
     <a class="nav-link" href="<?php echo e(route('role.index')); ?>">
         <i class="fas fa-fw fa-user"></i>
         <span>Jabatan</span>
     </a>
 </li>
<?php /**PATH D:\aperkat-laravel-11\resources\views/layout/super-admin.blade.php ENDPATH**/ ?>