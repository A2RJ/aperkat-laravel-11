

<?php $__env->startSection('title', 'Daftar Pengajuan PPUF | APERKAT'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card shadow">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Daftar Pengajuan Pada Bulan <?php echo e(ucfirst($period)); ?></h6>
            </div>

            <div class="card-body p-4">
                <div class="mb-4">
                    <form action="<?php echo e(url()->current()); ?>" method="get">
                        <div class="row">
                            <div class="col-sm">
                                <select id="status" class="form-control" name="status">
                                    <option value="">Pilih Status</option>
                                    <option value="need approve" <?php echo e(request('status', false) == 'need approve' ? 'selected' : ''); ?>>
                                        Menunggu Persetujuan
                                    </option>
                                    <option value="progress" <?php echo e(request('status', false) == 'progress' ? 'selected' : ''); ?>>
                                        Sedang Diproses</option>
                                    <option value="done" <?php echo e(request('status', false) == 'done' ? 'selected' : ''); ?>>
                                        Selesai
                                    </option>
                                </select>
                            </div>
                            <div class="col-sm ">
                                <input class="form-control " type="text" id="keyword" name="keyword" value="<?php echo e(request('keyword')); ?>" placeholder="Keyword">
                            </div>
                            <div class="col-sm">
                                <button class="btn bg-primary btn-primary px-4" type="submit">Filter</button>
                                <a href="<?php echo e(url()->current()); ?>"><button class="btn bg-warning btn-warning px-4" type="button">Clear</button></a>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Unit Pengaju</th>
                                <th scope="col">Status Pengajuan</th>
                                <th scope="col">Nomor PPUF</th>
                                <th scope="col">Nama Kegiatan</th>
                                <th scope="col">Latar Belakang</th>
                                <th scope="col">Tempat dan Waktu</th>
                                <th scope="col">RAB Diajukan (RAB Disetujui)</th>
                                <th scope="col">Periode Pencairan</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration + $submissions->firstItem() - 1); ?></th>
                                <td><?php echo e($submission->ppuf->author->role); ?></td>
                                <td class="<?php echo e($submission->status->last()->status ? 'text-success ': 'text-warning '); ?>">
                                    <?php if($submission->status->last()->message == 'LPJ telah disetujui'): ?>
                                    Selesai
                                    <?php else: ?>
                                    <?php echo e($submission->status->last()->role->role); ?>: <?php echo e(substr($submission->status->last()->message, 0, 10)); ?>...
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($submission->ppuf->ppuf_number); ?></td>
                                <td><?php echo e(substr($submission->ppuf->program_name, 0, 50)); ?></td>
                                <td><?php echo e(substr($submission->background, 0, 50)); ?></td>
                                <td><?php echo e(ucfirst($submission->place)); ?>, <?php echo e(ucfirst($submission->ppuf->date)); ?></td>
                                <td><?php echo e($submission->budget); ?> (<?php echo e($submission->approved_budget); ?>)</td>
                                <td><?php echo e($submission->period?->period); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <a class="btn btn-sm btn-success mr-1 mb-1" href="<?php echo e(route('submission.show', $submission->id)); ?>" target="_blank">
                                            <i class="fas fa-fw fa-info"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="float-right ">
                        <?php echo e($submissions->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aperkat-laravel-11\resources\views/period.blade.php ENDPATH**/ ?>