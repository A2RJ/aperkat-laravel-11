<?php $__env->startSection('title', 'Form Pengajuan PPUF | APERKAT'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card shadow">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Form Pengajuan PPUF</h6>
            </div>

            <div class="card-body p-4">

                <?php if(session()->has('failed')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('failed')); ?>.
                </div>
                <?php endif; ?>

                <form action="<?php echo e(route('submission.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col-12 col-lg-2 mb-3">
                            <label for="ppuf_id">Nomor PPUF</label>
                            <select class="w-100 border rounded selectpicker <?php $__errorArgs = ['ppuf_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ppuf_id" name="ppuf_id" data-live-search="true">
                                <option>Pilih Nomor PPUF</option>
                                <?php $__currentLoopData = $ppufs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ppuf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ppuf->id); ?>" <?php echo e(old('ppuf_id') == $ppuf->id ? 'selected' : ''); ?>>
                                    <?php echo e($ppuf->ppuf_number); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['ppuf_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-lg-4 mb-3">
                            <label for="ppuf_name">Nama Kegiatan</label>
                            <select class="w-100 border rounded custom-select" id="ppuf_name" name="ppuf_name">
                                <?php $__currentLoopData = $ppufs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ppuf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ppuf->id); ?>" selected data-chained="<?php echo e($ppuf->id); ?>">
                                    <?php echo e($ppuf->program_name); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-12 col-lg-3 mb-3">
                            <label for="rabkegiatan">RAB Kegiatan</label>
                            <select class="w-100 border rounded custom-select" id="rabkegiatan" name="rabkegiatan">
                                <?php $__currentLoopData = $ppufs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ppuf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ppuf->id); ?>" selected data-chained="<?php echo e($ppuf->id); ?>">
                                    <?php echo e($ppuf->budget); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-12 col-lg-3 mb-3">
                            <label for="activity_type">Jenis Kegiatan</label>
                            <select class="w-100 border rounded custom-select" id="activity_type" name="activity_type">
                                <?php $__currentLoopData = $ppufs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ppuf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e(strtolower($ppuf->activity_type)); ?>" selected data-chained="<?php echo e($ppuf->id); ?>">
                                    <?php echo e(ucfirst($ppuf->activity_type)); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-12 mb-3">
                            <label for="background">Latar Belakang</label>
                            <textarea rows="4" class="form-control <?php $__errorArgs = ['background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="background" name="background"><?php echo e(old('background')); ?></textarea>
                            <?php $__errorArgs = ['background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-lg-4  mb-3">
                            <label for="speaker">Pemateri</label>
                            <textarea class="form-control <?php $__errorArgs = ['speaker'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speaker" name="speaker"><?php echo e(old('speaker')); ?></textarea>
                            <?php $__errorArgs = ['speaker'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-lg-4  mb-3">
                            <label for="participant">Peserta</label>
                            <textarea class="form-control <?php $__errorArgs = ['participant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="participant" name="participant"><?php echo e(old('participant')); ?></textarea>
                            <?php $__errorArgs = ['participant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-lg-4  mb-3">
                            <label for="rundown">Rundown</label>
                            <textarea class="form-control <?php $__errorArgs = ['rundown'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="rundown" name="rundown"><?php echo e(old('rundown')); ?></textarea>
                            <?php $__errorArgs = ['rundown'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-lg-4 mb-3">
                            <label for="iku1_id">IKU 1</label>
                            <select class="custom-select w-100 border rounded <?php $__errorArgs = ['iku1_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="iku1_id" name="iku1_id" data-live-search="true">
                                <option>Pilih IKU</option>
                                <?php $__currentLoopData = $ikus['iku1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($iku->id); ?>" <?php echo e(old('iku1_id') == $iku->id ? 'selected' : ''); ?>>
                                    <?php echo e($iku->iku); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['iku1_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-lg-4 mb-3">
                            <label for="iku2_id">IKU 2</label>
                            <select class="custom-select w-100 border rounded <?php $__errorArgs = ['iku2_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="iku2_id" name="iku2_id" data-live-search="true">
                                <option>Pilih IKU</option>
                                <?php $__currentLoopData = $ikus['iku2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($iku->id); ?>" <?php echo e(old('iku2_id') == $iku->id ? 'selected' : ''); ?> data-chained="<?php echo e($iku->parent_id); ?>">
                                    <?php echo e($iku->iku); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['iku2_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-lg-4 mb-3">
                            <label for="iku3_id">IKU 3</label>
                            <select class="custom-select w-100 border rounded <?php $__errorArgs = ['iku3_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="iku3_id" name="iku3_id" data-live-search="true">
                                <option>Pilih IKU</option>
                                <?php $__currentLoopData = $ikus['iku3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($iku->id); ?>" <?php echo e(old('iku3_id') == $iku->id ? 'selected' : ''); ?> data-chained="<?php echo e($iku->parent_id); ?>">
                                    <?php echo e($iku->iku); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['iku3_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-lg-4 mb-3">
                            <label for="vendor">Vendor</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['vendor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="vendor" name="vendor" value="<?php echo e(old('vendor')); ?>">
                            <?php $__errorArgs = ['vendor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-lg-4 mb-3">
                            <label for="place">Tempat Pelaksanaan</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="place" name="place" value="<?php echo e(old('place')); ?>">
                            <?php $__errorArgs = ['place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-lg-4 mb-3">
                            <label for="date">Waktu Pelaksanaan</label>
                            <select class="w-100 border rounded custom-select" id="date" name="date">
                                <?php $__currentLoopData = $ppufs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ppuf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ppuf->id); ?>" selected data-chained="<?php echo e($ppuf->id); ?>">
                                    <?php echo e(ucfirst($ppuf->date)); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label for="rab">Detail RAB</label>
                        <div id="rabs-container">
                            <?php $__currentLoopData = old('rab', [['item' => '', 'qty' => '', 'harga_satuan' => '', 'total' => '', 'detail' => '']]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row mb-1 rab-<?php echo e($index); ?> rab">
                                <div class="col-sm mb-1">
                                    <input type="text" class="form-control <?php $__errorArgs = ['rab.' . $index . '.item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="item" name="rab[<?php echo e($index); ?>][item]" placeholder="Item" value="<?php echo e($row['item']); ?>">
                                    <?php $__errorArgs = ['rab.' . $index . '.item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-sm mb-1">
                                    <input type="number" class="form-control <?php $__errorArgs = ['rab.' . $index . '.qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="qty" name="rab[<?php echo e($index); ?>][qty]" placeholder="Qty" value="<?php echo e($row['qty']); ?>" oninput="calculateTotal('<?php echo e($index); ?>')">
                                    <?php $__errorArgs = ['rab.' . $index . '.qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-sm mb-1">
                                    <input type="number" class="form-control <?php $__errorArgs = ['rab.' . $index . '.harga_satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga_satuan" name="rab[<?php echo e($index); ?>][harga_satuan]" placeholder="Harga Satuan" value="<?php echo e($row['harga_satuan']); ?>" oninput="calculateTotal('<?php echo e($index); ?>')">
                                    <?php $__errorArgs = ['rab.' . $index . '.harga_satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-sm mb-1">
                                    <input type="number" class="form-control <?php $__errorArgs = ['rab.' . $index . '.total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total" name="rab[<?php echo e($index); ?>][total]" placeholder="Total" value="<?php echo e($row['total']); ?>" readonly>
                                    <?php $__errorArgs = ['rab.' . $index . '.total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-sm mb-1">
                                    <input type="text" class="form-control <?php $__errorArgs = ['rab.' . $index . '.detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="detail" name="rab[<?php echo e($index); ?>][detail]" placeholder="Detail" value="<?php echo e($row['detail']); ?>">
                                    <?php $__errorArgs = ['rab.' . $index . '.detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-sm mb-1">
                                    <?php if($index == 0): ?>
                                    <button class="btn btn-danger" type="button" disabled>Remove</button>
                                    <?php else: ?>
                                    <button class="btn bg-danger btn-danger" type="button" onclick="removeRab('<?php echo e($index); ?>')">Remove</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="mt-2 mb-3 row">
                            <div class="col-4">
                                <input type="text" class="form-control" id="totalRab" name="totalRab" value="Rp. 0">
                            </div>
                            <div class="col-4">
                                <button class="btn bg-primary btn-primary" type="button" onclick="addRab()">Tambah</button>
                            </div>
                        </div>
                    </div>


                    <div>
                        <button type="submit" class="btn bg-primary btn-primary float-right ">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    function calculateTotal(index) {
        var qty = parseFloat(document.querySelector('.rab-' + index + ' input[name="rab[' + index + '][qty]"]').value);
        var hargaSatuan = parseFloat(document.querySelector('.rab-' + index + ' input[name="rab[' + index +
            '][harga_satuan]"]').value);
        var total = qty * hargaSatuan;
        console.log(total);
        if (!isNaN(total)) {
            document.querySelector('.rab-' + index + ' input[name="rab[' + index + '][total]"]').value = total;
            updateRabInput();
        }
    }


    function updateRabInput() {
        var totalRab = 0;
        var rabs = document.querySelectorAll('.rab');
        rabs.forEach(function(rab, index) {
            var qty = parseFloat(rab.querySelector('input[name="rab[' + index + '][qty]"]').value);
            var hargaSatuan = parseFloat(rab.querySelector('input[name="rab[' + index + '][harga_satuan]"]')
                .value);
            var total = qty * hargaSatuan;
            if (!isNaN(total)) {
                totalRab += total;
            }
        });
        document.getElementById('totalRab').value = formatRupiah(totalRab); // Menyimpan total dengan dua angka desimal
    }


    function addRab() {
        var rabsContainer = document.getElementById('rabs-container');
        var index = rabsContainer.querySelectorAll('.rab').length;
        var newRow = document.createElement('div');
        newRow.classList.add('row', 'mb-1', 'rab-' + index, 'rab');
        newRow.innerHTML = `
            <div class="col-sm mb-1">
                <input type="text" class="form-control" name="rab[${index}][item]" placeholder="Item">
            </div>
            <div class="col-sm mb-1">
                <input type="number" class="form-control" name="rab[${index}][qty]" placeholder="Qty" oninput="calculateTotal(${index})">
            </div>
            <div class="col-sm mb-1">
                <input type="number" class="form-control" name="rab[${index}][harga_satuan]" placeholder="Harga Satuan" oninput="calculateTotal(${index})">
            </div>
            <div class="col-sm mb-1">
                <input type="number" class="form-control" name="rab[${index}][total]" placeholder="Total" readonly>
            </div>
            <div class="col-sm mb-1">
                <input type="text" class="form-control" name="rab[${index}][detail]" placeholder="Detail">
            </div>
            <div class="col-sm mb-1">
                <button class="btn bg-danger btn-danger" type="button" onclick="removeRab(${index})">Remove</button>
            </div>
        `;
        rabsContainer.appendChild(newRow);
    }

    function removeRab(index) {
        var rabsContainer = document.getElementById('rabs-container');
        var rabToRemove = document.querySelector('.rab-' + index);
        rabsContainer.removeChild(rabToRemove);
        updateRabInput();
    }

    function formatRupiah(angka, prefix = 'Rp. ') {
        var number_string = angka.toString().replace(/[^0-9]/g, '');
        var split = number_string.split(',');
        var sisa = split[0].length % 3;
        var rupiah = split[0].substr(0, sisa);
        var ribuan = split[0].substr(sisa).match(/\d{3}/g);

        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptjs'); ?>
<script src="/sb-admin-2/vendor/bootstrap-select/bootstrap-select.min.js"></script>
<script src="/sb-admin-2/vendor/jquery-select-chained/jquery.chained.js" type="text/javascript" charset="utf-8">
</script>
<script type="text/javascript" charset="utf-8">
    $(function() {
        $('.selectpicker').selectpicker()
        $("#iku2_id").chained("#iku1_id");
        $("#iku3_id").chained("#iku2_id");
        $("#ppuf_name").chained("#ppuf_id");
        $("#rabkegiatan").chained("#ppuf_id");
        $("#activity_type").chained("#ppuf_id");
        $("#date").chained("#ppuf_id");

        function checkDisable(selectId, inputId, selectedValue) {
            var selectValue = document.getElementById(selectId).value;
            var inputToDisable = document.getElementById(inputId);

            if (selectValue === selectedValue) {
                inputToDisable.disabled = true;
            } else {
                inputToDisable.disabled = false;
            }
        }

        document.getElementById("activity_type").onchange = optional

        function optional() {
            var selectBox = document.getElementById("activity_type");
            var selectedText = selectBox.options[selectBox.selectedIndex].textContent;
            selectedText = selectedText.replace(/\s/g, '');

            var textareaPeserta = document.getElementById("participant");
            if (selectedText !== 'Program') {
                textareaPeserta.setAttribute('disabled', 'disabled');
            } else {
                textareaPeserta.removeAttribute('disabled');
            }

            var speaker = document.getElementById("speaker");
            if (selectedText !== 'Program') {
                speaker.setAttribute('disabled', 'disabled');
            } else {
                speaker.removeAttribute('disabled');
            }

            var rundown = document.getElementById("rundown");
            if (selectedText !== 'Program') {
                rundown.setAttribute('disabled', 'disabled');
            } else {
                rundown.removeAttribute('disabled');
            }

            var rundown = document.getElementById("vendor");
            if (selectedText === 'Program') {
                rundown.setAttribute('disabled', 'disabled');
            } else {
                rundown.removeAttribute('disabled');
            }
        };
        optional()
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aperkat-laravel-11\resources\views/submission/create.blade.php ENDPATH**/ ?>