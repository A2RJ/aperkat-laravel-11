 <div class="sidebar-heading">
     Direktur Keuangan
 </div>
 <li class="nav-item">
     <a class="nav-link" href="{{ route('ppuf.index') }}">
         <i class="fas fa-fw fa-table"></i>
         <span>PPUF</span>
     </a>
 </li>

 <li class="nav-item">
     <a class="nav-link" href="{{ route('submission.index') }}">
         <i class="fas fa-fw fa-table"></i>
         <span>Pengajuan</span>
     </a>
 </li>

 <li class="nav-item">
     <a class="nav-link" href="{{ route('disbursement-period.index') }}">
         <i class="fas fa-fw fa-table"></i>
         <span>Periode Pencairan</span>
     </a>
 </li>

 <li class="nav-item">
     <a class="nav-link" href="{{ route('submission.dir-keuangan') }}">
         <i class="fas fa-fw fa-folder"></i>
         <span>Pengajuan Sub Divisi</span>
     </a>
 </li>
