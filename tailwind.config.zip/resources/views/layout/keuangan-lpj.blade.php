 <div class="sidebar-heading">
     Direktur Keuangan - LPJ
 </div>
 <li class="nav-item">
     <a class="nav-link" href="{{ route('submission.admin-lpj') }}">
         <i class="fas fa-fw fa-folder"></i>
         <span>Pengajuan Sub Divisi</span>
     </a>
 </li>
